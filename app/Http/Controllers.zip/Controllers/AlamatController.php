<?php

namespace App\Http\Controllers;

use DateTime;
use App\Models\TpsModel;
use App\Models\User;
use App\Models\RtrwModel;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Helpers\GenerateNumberHelpers;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon; 
class AlamatController extends Controller
{
    //
}
